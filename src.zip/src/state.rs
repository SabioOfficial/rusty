use std::{collections::HashMap, error::Error, sync::RwLock};

use tokio::sync::mpsc;
use twilight_model::id::{
  Id,
  marker::{ChannelMarker, GuildMarker, MessageMarker, UserMarker},
};

pub type BoxErr = Box<dyn Error + Send + Sync>;

pub type Job = (u64, Id<ChannelMarker>, Id<MessageMarker>);

#[derive(Clone, Copy)]
pub struct PrivateVc {
  owner: Id<UserMarker>,
  expires_ms: u64,
}

#[derive(Clone, Copy)]
pub struct Disappear {
  secs: u64,
  since_ms: u64,
}

#[derive(Clone)]
pub struct Anchor {
  text: String,
  last: Option<Id<MessageMarker>>,
  tick: u64,
  unintrusive: bool,
  last_msg_ms: u64,
}

pub struct State {
  redirects: RwLock<HashMap<Id<GuildMarker>, Id<UserMarker>>>,
  disappear: RwLock<HashMap<Id<ChannelMarker>, Disappear>>,
  vcs: RwLock<HashMap<Id<ChannelMarker>, PrivateVc>>,
  anchors: RwLock<HashMap<Id<ChannelMarker>, Anchor>>,
  logs: RwLock<HashMap<Id<GuildMarker>, Id<ChannelMarker>>>,
  tx: mpsc::UnboundedSender<Job>,
  bot_id: Id<UserMarker>,
}